
'use strict'
const mongoose = require('mongoose')

mongoose.connect('mongodb://127.0.0.1:27017/test')

const express = require('express')
const app = express()
const port = process.env.port || 3000
const clientRouter = require('./src/routers/clientRouter')
const productRouter = require('./src/routers/productRouter')
const funcionarioRouter = require('./src/routers/funcionarioRouter')
const promocaoRouter = require('./src/routers/promocaoRouter')

app.use(express.json())
app.use(clientRouter)
app.use(productRouter)
app.use(funcionarioRouter)
app.use(promocaoRouter)
app.listen(port, () => {
    console.log(`O servidor está executando na porta ${port}`)
})