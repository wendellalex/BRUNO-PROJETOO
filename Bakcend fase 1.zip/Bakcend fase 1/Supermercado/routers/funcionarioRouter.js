'use strict'
const express = require('express')
const funcionarioRouter = express.Router()
const funcionarioController = require('../controllers/funcinarioController')

funcionarioRouter.route('/api/funcinarios')
.get((req, res) => funcinarioController.getFuncionario(req, res))
.post((req, res) => funcinarioController.createFuncionario(req, res))
.put((req, res) => funcinarioController.updateFuncionario(req, res))

funcionarioRouter.route('/api/funcinarios/:id')
.get((req, res) => funcinarioController.getFuncionario(req, res))
.delete((req, res) => funcinarioController.deleteFuncionarioById(req, res))

module.exports = funcinarioRouter