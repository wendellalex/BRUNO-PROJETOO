'use strict'
const express = require('express')
const productRouter = express.Router()
const productController = require('../controllers/productController')

productRouter.route('/api/students')
.get((req, res) => productController.getProduct(req, res))
.post((req, res) => productController.createProduct(req, res))
.put((req, res) => productController.updateProduct(req, res))

productRouter.route('/api/products/:id')
.get((req, res) => productController.getProduct(req, res))
.delete((req, res) => productController.deleteProductById(req, res))

module.exports = productRouter