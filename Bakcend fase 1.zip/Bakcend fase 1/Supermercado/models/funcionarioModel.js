const mongoose = require('mongoose')
const Schema = mongoose.Schema
const funcionarioSchema = new Schema({
    
    name: {type: String, required: true},
    age: {type: Number, min:18, max: 150},
    wage: {type: Number, required: true, unique: true},
    course: String
})

module.exports = mongoose.model("FuncionarioModel", funcionarioSchema)