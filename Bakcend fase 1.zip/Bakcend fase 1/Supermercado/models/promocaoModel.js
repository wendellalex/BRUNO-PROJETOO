const mongoose = require('mongoose')
const Schema = mongoose.Schema
const promocaoSchema = new Schema({
 
    name: {type: String, required: true},
    price: {type: Number, min:2, max: 150},
    type: {type: String, required: true},
    course: String
})


module.exports = mongoose.model("PromocaoModel", promocaoSchema)